const KEY="nixaroid_demo";
const state=JSON.parse(localStorage.getItem(KEY)||'{"user":null,"balance":0,"reward":28,"orders":[],"tickets":[],"transactions":[]}');
const save=()=>localStorage.setItem(KEY,JSON.stringify(state));
const money=n=>`₦${Number(n).toLocaleString("en-NG",{minimumFractionDigits:2})}`;
const app=document.getElementById("app");

function toast(t){const x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),2200)}
function header(){return `<header class="top"><div class="logo">nix<b>a</b>roid</div>${state.user?`<span>NGN</span><button class="btn light" onclick="logout()">Logout</button>`:""}</header>`}
function nav(active){return state.user?`<nav class="bottom">
<button class="${active==="home"?"active":""}" onclick="go('home')"><span>⌂</span><small>Dashboard</small></button>
<button class="${active==="bills"?"active":""}" onclick="go('bills')"><span>▣</span><small>Bills</small></button>
<button class="${active==="boost"?"active":""}" onclick="go('boost')"><span>🚀</span><small>Boost</small></button>
<button class="${active==="history"?"active":""}" onclick="go('history')"><span>▤</span><small>History</small></button>
<button class="${active==="menu"?"active":""}" onclick="go('menu')"><span>☰</span><small>Menu</small></button></nav>`:""}

function login(){app.innerHTML=`${header()}<main class="container"><section class="card form">
<h1>Welcome back</h1><p class="muted">Demo account — data stays in your browser.</p>
<div class="field"><label>Email</label><input id="email" type="email" placeholder="you@example.com"></div>
<div class="field"><label>Password</label><input id="pass" type="password" placeholder="Password"></div>
<button class="btn" style="width:100%" onclick="doLogin()">Login</button>
<p class="muted">No account? <a href="#" onclick="register();return false">Create one</a></p></section></main>`}
function register(){app.innerHTML=`${header()}<main class="container"><section class="card form">
<h1>Create account</h1><div class="field"><label>Name</label><input id="name" placeholder="Your name"></div>
<div class="field"><label>Email</label><input id="email" type="email" placeholder="you@example.com"></div>
<div class="field"><label>Password</label><input id="pass" type="password" placeholder="At least 6 characters"></div>
<button class="btn" style="width:100%" onclick="doRegister()">Create account</button>
<p><a href="#" onclick="login();return false">Back to login</a></p></section></main>`}
function doLogin(){const email=document.getElementById("email").value.trim();if(!email)return toast("Enter your email");state.user={name:email.split("@")[0],email};save();go("home")}
function doRegister(){const name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim(),pass=document.getElementById("pass").value;if(!name||!email||pass.length<6)return toast("Complete the form");state.user={name,email};save();go("home")}
function logout(){state.user=null;save();login()}

function home(){app.innerHTML=`${header()}<main class="container">
<div class="notice"><span>Enable notifications to stay updated with your account and orders.</span><button class="btn" onclick="toast('Notifications enabled for this demo')">Allow</button></div>
<section class="wallet"><div class="row between"><div><small>MAIN BALANCE</small><h1 id="bal">${money(state.balance)}</h1></div><button class="btn light" onclick="toggleBalance()">◉</button></div>
<div class="row"><div class="reward"><b>★ Reward</b><br><small>Balance: ${money(state.reward)}</small></div><button class="btn" onclick="deposit()">⊕ Deposit</button></div>
<div class="stats"><div class="stat"><small>DEPOSITS</small><strong>${money(state.transactions.filter(x=>x.type==="Deposit").reduce((a,x)=>a+x.amount,0))}</strong></div><div class="stat"><small>ORDERS</small><strong>${state.orders.length}</strong><small class="gold">0 Active</small></div><div class="stat"><small>SUPPORT</small><strong>${state.tickets.length}</strong><small class="gold">0 Pending</small></div></div></section>
<div class="section-title">⚡ QUICK ACCESS</div><div class="quick">
<button onclick="go('boost')"><span>🚀</span>Social Boost</button><button onclick="go('bills')"><span>☎</span>Airtime</button><button onclick="ticket()"><span>🎟</span>New Ticket</button><button onclick="go('bills')"><span>▣</span>Pay Bills</button><button onclick="go('history')"><span>💵</span>History</button></div>
<div class="section-title">OUR SERVICES</div><div class="services"><article class="service purple" onclick="go('bills')"><div class="service-icon">▣</div><h2>Bills & Payments</h2><p class="muted">Airtime, data, cable, electricity</p></article><article class="service blue" onclick="go('boost')"><div class="service-icon">🚀</div><h2>Social Boost</h2><p class="muted">Followers, likes, views, engagement</p></article></div>
</main>${nav("home")}`}
function toggleBalance(){const b=document.getElementById("bal");b.dataset.hidden=b.dataset.hidden==="1"?"0":"1";b.textContent=b.dataset.hidden==="1"?"₦••••••":money(state.balance)}
function deposit(){const n=prompt("Demo deposit amount (no real payment):","5000");const amount=Number(n);if(!amount||amount<1)return;state.balance+=amount;state.transactions.unshift({type:"Deposit",amount,date:new Date().toLocaleString()});save();home();toast("Demo balance updated")}
function bills(){app.innerHTML=`${header()}<main class="container"><section class="card"><h1>Bills & Payments</h1><p class="muted">Demo interface — no real transaction is processed.</p>
<div class="field"><label>Service</label><select id="svc"><option>Airtime</option><option>Mobile Data</option><option>Cable TV</option><option>Electricity</option></select></div>
<div class="field"><label>Phone / Account number</label><input id="acct" placeholder="Enter number"></div><div class="field"><label>Amount</label><input id="amt" type="number" placeholder="1000"></div>
<button class="btn" onclick="buyBill()">Continue</button></section></main>${nav("bills")}`}
function buyBill(){const amount=Number(document.getElementById("amt").value);if(!amount||amount>state.balance)return toast("Insufficient demo balance");state.balance-=amount;state.transactions.unshift({type:"Bill",amount:-amount,date:new Date().toLocaleString()});save();home();toast("Demo bill recorded")}
function boost(){app.innerHTML=`${header()}<main class="container"><section class="card"><h1>Social Boost</h1><p class="muted">Demo order form. No social-media action is performed.</p>
<div class="field"><label>Service</label><select id="service"><option>Followers</option><option>Likes</option><option>Views</option><option>Comments</option></select></div><div class="field"><label>Profile / post URL</label><input id="url" placeholder="https://example.com/..."></div><div class="field"><label>Quantity</label><input id="qty" type="number" placeholder="100"></div><button class="btn" onclick="placeOrder()">Place demo order</button></section></main>${nav("boost")}`}
function placeOrder(){const q=Number(document.getElementById("qty").value);if(!q)return toast("Enter quantity");state.orders.unshift({service:document.getElementById("service").value,quantity:q,date:new Date().toLocaleString(),status:"Pending"});save();toast("Demo order created");go("history")}
function history(){app.innerHTML=`${header()}<main class="container"><section class="card"><h1>History</h1><div class="section-title">Transactions</div><div class="list">${state.transactions.length?state.transactions.map(x=>`<div class="item"><span>${x.type}<br><small>${x.date}</small></span><b>${money(x.amount)}</b></div>`).join(""):"<div class='empty muted'>No transactions yet.</div>"}</div><div class="section-title">Orders</div><div class="list">${state.orders.length?state.orders.map(x=>`<div class="item"><span>${x.service} × ${x.quantity}<br><small>${x.date}</small></span><b>${x.status}</b></div>`).join(""):"<div class='empty muted'>No orders yet.</div>"}</div></section></main>${nav("history")}`}
function ticket(){const t=prompt("Describe your support issue:");if(!t)return;state.tickets.unshift({text:t,date:new Date().toLocaleString()});save();toast("Demo ticket created")}
function menu(){app.innerHTML=`${header()}<main class="container"><section class="card"><h1>Account</h1><p><b>${state.user.name}</b><br><span class="muted">${state.user.email}</span></p><hr><button class="btn light" onclick="ticket()">Create support ticket</button> <button class="btn" onclick="logout()">Logout</button></section></main>${nav("menu")}`}
function go(p){({home,bills,boost,history,menu}[p])()}
if(state.user)home();else login();
