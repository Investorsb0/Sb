NIXAROID FULL FRONT-END DEMO

Files:
- index.html
- style.css
- app.js

SPCK:
1. Create a project.
2. Add the three files above.
3. Paste each file's contents into the matching file.
4. Preview index.html.

This is a front-end/demo application. It uses localStorage in the browser for demo login, balance, transactions, orders and tickets.

IMPORTANT:
It does NOT process real payments, real airtime/data purchases, or real social-media orders. To make those real, a secure backend, database, authentication system, and legitimate payment/service APIs must be added.
